package hash
